var min = 1;
var max = 5;
var current = min;

function updateIcon() {
  chrome.browserAction.setIcon({path:"icon" + current + ".png"});
  current++;

  if (current > max)
    current = min;
}

//doesnt run if extension has a popup
// chrome.browserAction.onClicked.addListener(updateIcon);

//injects script into active tab when button is clicked
document.querySelector('button#make-red').addEventListener('click', function(){
  chrome.tabs.executeScript({
    file: "injected.js"
  })
})


document.querySelector('button#change-icon').addEventListener('click', updateIcon)

