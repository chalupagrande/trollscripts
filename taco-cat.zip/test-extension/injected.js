function setup(){
  var a = [...document.querySelectorAll('img')]
   a.forEach((e)=>{
    e.setAttribute('src','http://i.giphy.com/ZU7hwTPLSnZcs.gif')
  })
}
setup()